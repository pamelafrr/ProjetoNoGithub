# Exercício 3
# Tarefa - Fazer
# Escreva um programa que produza uma história. A história e a conclusão da história devem sair em várias linhas.

# Tarefa - Fazer

# Escreva um programa que gere uma história com várias linhas.

# Tarefa de extensão 1
# Existe uma maneira de usar uma única instrução de impressão para gerar texto em várias linhas. Crie o programa de história que funciona da mesma forma do que anteriormente, mas usa apenas uma instrução de impressão.#
historia1 = """ola mundo
essa historia é doida, aqui um dia eu vi uma aula, essa aula me enloqueceu, nao sabia se era aspas simples ou duplas, aspenas escrivi em aspas tripla, que loucura, o que eu faço?"""

print(historia1)

# Tarefa de extensão 2
# Existe uma maneira de adicionar um atraso de tempo no código python. Faça alguma pesquisa e crie um programa de história que produza a história e atrase antes de gerar a conclusão.
historia2 = """Conclusâo
Depois de tanto estudo e entendimento precisei colocar
essa historia para dormir. E assim se fez esse programa."""

import time

time.sleep(3)
print(historia2)
