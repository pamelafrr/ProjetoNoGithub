# Exercício 7
# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.
# Emita o conteúdo das variáveis em 2 linhas separadas.

# Atribuição de Variáveis
name1 = "nome"
name2 = "fruta"

# Atribua seu nome e sua comida favorita a 2 variáveis separadas com nomes adequados.
name1 = "pamela"
name2 = "pessego"

############# SIMPLES ###################

# Mostra o conteúdo das variáveis em 2 linhas separadas
print (name1)
print (name2)
# Tarefa de extensão 1
# Emita duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.

name1 = "meu nome é pamela" 
name2 = "minha fruta preferida e pessego"
print (name1 + " e " + name2)

############# MÉDIO ####################

# Saída de duas frases (não apenas o conteúdo das variáveis). O primeiro com seu nome, o segundo com sua comida favorita.
print (name1)  
print (name2)
# Tarefa de extensão 2
# Emita ambas as informações como parte da mesma frase. Certifique-se de ter espaços e pontuação nos lugares corretos.
print (name1 + " e " + name2) 
############# COMPLEXO ###################

# Emita ambas as informações como parte da mesma frase.
print (name1 + " e " + name2)
# Certifique-se de ter espaços e pontuação nos lugares corretos.

