# Exercício 14
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule o volume de um paralelepípedo. Onde você informará o comprimento, a largura e a altura. 

# Fórmula: V = c x l x h

# Onde: V = Volume

# c = comprimento

# l = largura

# h = altura

# Escreva seu código aqui#

c = input("informe o comprimento") 
l = input("informe a largura") 
h = input("informe a altura")

V = int(c) * int(l) * int(h) 

print (V) 