# Exercício 10
# Escreva um código que funcione de acordo com o enunciado

# Você está enchendo uma piscina e tem 3 mangueiras. A mangueira vermelha enche em 2 horas, a mangueira azul leva 1,2 hora e a mangueira amarela em 1 hora. Você deseja acelerar o processo usando as três mangueiras. Quanto tempo levará usando todas as mangueiras, em minutos?

# Escreva seu código aqui