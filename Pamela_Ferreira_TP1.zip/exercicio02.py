# Exercício 2
# Adapte o código para gerar sua própria mensagem e adicione comentários para mostrar o que ele faz.

print(
    "Eu estou adorando Python! Que curso legal. Eu amo aprender coisas novas.")
# Ele está mostrando uma mensagem na tela.

"""Ajuda! Meu código não funciona!

Certifique-se de verificar os seguintes itens:

O print não tem letras maiúsculas;
O texto da string é cercado por marcas de fala " " (aspas duplas); 
A string (incluindo marcas de fala) é cercada por parênteses ( )."""
