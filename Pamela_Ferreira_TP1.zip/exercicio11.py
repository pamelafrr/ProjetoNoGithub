# Exercício 11
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que somará dois números e mostrará a média desses números como resultado.

# Escreva seu código aqui
numero1 = input("digite o primeiro numero")
numero2 = input("digite o segundo numero")

resultado = int(numero1) + int(numero2)  
resultado = resultado / 2 

print (resultado)