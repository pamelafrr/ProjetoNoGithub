# Exercício 11
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que somará dois números e mostrará a média desses números como resultado.

# Escreva seu código aqui

