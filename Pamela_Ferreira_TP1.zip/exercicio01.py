# Exercício 1
#Tarefa - Prever e Executar
#Olhe para o código de exemplo, estude-o cuidadosamente. Escreva uma previsão do que ele fará quando for executado. Sua previsão deve ser adicionada ao código como comentários. Você deve usar os termos-chave executar, produzir e string em sua previsão.

print("Hello World!") 

# Minha previsão, adicione sua previsão como comentário
# Minha previsão é que apos o print ele meu projeto será mostrado na tela ao lado

# Tarefa - Investigar
# Use comentários para responder às perguntas de investigação no código de exemplo.

# Qual parte do código de exemplo é a instrução de saída?

# Responda:
# A instrução de saída é o print.

# Qual parte do código de exemplo é a string?

# Responda:
# A string é o texto entre as aspas, ou seja, é o Hello World.

# Qual seria a saída do código print("I love Computing")?

# Responda:
# A saída seria o texto do print "I love Computing".

# O que aconteceria se o código print("I love Comping") fosse executado?

# Responda:
# Ele aparecerá na tela a mensagem "I love Comping"

# O que aconteceria se o código print("I love Computing" fosse executado?

# Responda:
# Ele irá gerar um erro, porque nao foi fechado o metódo print, ou seja, o correto seria: print("I love Computing")

"""Ajuda! Meu código não funciona!

Certifique-se de verificar os seguintes itens:

O print não tem letra maiúscula;
O texto da string é cercado por aspas duplas (“) ou aspas simples (‘);
A string (incluindo aspas) é cercada por parênteses."""
