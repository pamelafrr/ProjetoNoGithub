# Exercício 6
# Adapte o código para gerar o que está sendo pedido nos comentários. Complemente com comentários para deixar seu código bastante claro.

# Atribuição de Variável - Modificar

# Você pode combinar variáveis com strings em uma saída

name1 = "Axl"
name2 = "Slash"
name3 = "Duff"
name4 = "Izzy"

# Adicione mais 2 variáveis para armazenar 'Duff' e 'Izzy'
# Adicionados. 

#Esta linha usa concatenação para juntar as variáveis com a string 'and' para formar uma frase.

#Complete a linha para gerar todas as variáveis

print(name1 + " and " + name2 + " and " + name3 + " and " + name4) 


"""Ajuda! Meu código não funciona!

Certifique-se de verificar os seguintes itens:

O print não tem letra maiúscula;
O texto da string é cercado por aspas;
A string (incluindo aspas) é cercada por parênteses;
Variável vai à esquerda, dados à direita para atribuição;
Você usou um '+' entre cada string e variável que precisa ser concatenada."""