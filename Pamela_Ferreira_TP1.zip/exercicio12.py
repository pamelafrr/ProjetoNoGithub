# Exercício 12
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule a área de um triângulo. Onde você informará a base e a altura.

# Fórmula: A = (b x h) / 2

# Onde: A = Área

# b = base

# h = altura

# Escreva seu código aqui

b = input("informe a base") 
h = input("informe a altura") 

A = int(b) * int(h)
A = A/2

print (A) 
