# Exercício 12
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que calcule a área de um triângulo. Onde você informará a base e a altura. 

# Fórmula: A = (b x h) / 2

# Onde: A = Área

# b = base

# h = altura

# Escreva seu código aqui